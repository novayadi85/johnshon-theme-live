# Graph Report - johnshonwine-work-jeppe  (2026-07-27)

## Corpus Check
- 151 files · ~206,567 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1081 nodes · 2130 edges · 67 communities (28 shown, 39 thin omitted)
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS · INFERRED: 7 edges (avg confidence: 0.71)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `d90d3f47`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Slideshow
- facets.js
- startViewTransition
- utilities.js
- popover-polyfill.js
- ProductCard
- component.js
- DeferredMedia
- QuickOrderListComponent
- LayeredSlideshowComponent
- LocalizationFormComponent
- PredictiveSearchComponent
- ProductFormComponent
- QuantitySelectorComponent
- DragZoomWrapper
- Scroller
- qr-code-generator.js
- QuickAddComponent
- onAnimationEnd
- events.js
- HeaderDrawer
- OverflowList
- GiftCardRecipientForm
- HeaderMenu
- VariantPicker
- PaginatedList
- CartItemsComponent
- morph
- ProductHotspotComponent
- StickyAddToCartComponent
- product-card.js
- JumboText
- AnnouncementBar
- compilerOptions
- MarqueeComponent
- ScrollHint
- PaginatedListAspectRatioHelper
- AGENTS.md
- jkl-search-drawer.js
- theme-editor.js
- DialogComponent
- MediaGallery
- ComparisonSliderComponent
- PricePerItemComponent
- ShowMoreComponent
- AnchoredPopoverComponent
- CartIcon
- HeaderComponent
- ProductTitle
- debounce
- ThemePerformance
- ProductCardLink
- FloatingPanelComponent
- HeaderActions
- ProductPrice
- ProductSkuComponent
- VolumePricingInfoComponent
- ProductCustomProperty
- RTEFormatter
- SearchPageInputComponent
- view-transitions.js

## God Nodes (most connected - your core abstractions)
1. `Component` - 60 edges
2. `Slideshow` - 40 edges
3. `LayeredSlideshowComponent` - 28 edges
4. `QuickOrderListComponent` - 28 edges
5. `morph()` - 26 edges
6. `ProductCard` - 26 edges
7. `DragZoomWrapper` - 22 edges
8. `OverflowList` - 22 edges
9. `PredictiveSearchComponent` - 21 edges
10. `onAnimationEnd()` - 21 edges

## Surprising Connections (you probably didn't know these)
- `init()` --indirect_call--> `closeDrawer()`  [INFERRED]
  assets/jkl-filter-drawer.js → assets/jkl-search-drawer.js
- `init()` --indirect_call--> `openDrawer()`  [INFERRED]
  assets/jkl-filter-drawer.js → assets/jkl-search-drawer.js
- `morphSection()` --calls--> `morph()`  [EXTRACTED]
  assets/section-renderer.js → assets/morph.js
- `hydrateSection()` --calls--> `buildSectionSelector()`  [EXTRACTED]
  assets/section-hydration.js → assets/section-renderer.js
- `hydrateSection()` --calls--> `normalizeSectionId()`  [EXTRACTED]
  assets/section-hydration.js → assets/section-renderer.js

## Import Cycles
- None detected.

## Communities (67 total, 39 thin omitted)

### Community 1 - "facets.js"
Cohesion: 0.06
Nodes (12): FilterUpdateEvent, FacetClearComponent, FacetInputsComponent, FacetRemoveComponent, FacetsFormComponent, FacetStatusComponent, PriceFacetComponent, SortingFilterComponent (+4 more)

### Community 2 - "startViewTransition"
Cohesion: 0.06
Nodes (15): JumboText, ResultsList, calculatePaddingStart(), getScrollAxis(), Scroller, ScrollHint, scrollIntoView(), isLowPowerDevice() (+7 more)

### Community 3 - "utilities.js"
Cohesion: 0.12
Nodes (17): calculateHeaderGroupHeight(), changeMetaThemeColor(), getIOSVersion(), isClickedOutside(), isMobileBreakpoint(), isPointWithinElement(), isTouchDevice(), mediaQueryLarge (+9 more)

### Community 4 - "popover-polyfill.js"
Cohesion: 0.16
Nodes (29): apply(), checkPopoverValidity(), closeAllOpenPopovers(), closeAllOpenPopoversInList(), focusDelegate(), getPopoverVisibilityState(), getRootNode(), getStackPosition() (+21 more)

### Community 6 - "component.js"
Cohesion: 0.10
Nodes (7): Component, getAncestor(), getClosestComponent(), registerEventListeners(), CopyToClipboardComponent, VideoBackgroundComponent, VolumePricingComponent

### Community 7 - "DeferredMedia"
Cohesion: 0.09
Nodes (9): LoadCallback, ModelViewer, Navigator, Shopify, ShopifyFeature, Theme, Window, DeferredMedia (+1 more)

### Community 10 - "LocalizationFormComponent"
Cohesion: 0.12
Nodes (4): DrawerLocalizationComponent, DropdownLocalizationComponent, LocalizationFormComponent, normalizeString()

### Community 13 - "QuantitySelectorComponent"
Cohesion: 0.17
Nodes (3): CartQuantitySelectorComponent, QuantitySelectorComponent, parseIntOrDefault()

### Community 15 - "Scroller"
Cohesion: 0.24
Nodes (6): CartNote, CartAddEvent, CartUpdateEvent, DiscountUpdateEvent, cartPerformance, fetchConfig()

### Community 16 - "qr-code-generator.js"
Cohesion: 0.11
Nodes (8): getTypeNumber(), getUTF8Length(), onMakeImage(), QRCode(), QRErrorCorrectLevel, QRMaskPattern, QRMode, QRCodeImage

### Community 18 - "onAnimationEnd"
Cohesion: 0.29
Nodes (4): DialogCloseEvent, DialogOpenEvent, MediaStartedPlayingEvent, onAnimationEnd()

### Community 19 - "events.js"
Cohesion: 0.17
Nodes (8): MissingRefError, parseData(), parseValue(), CartErrorEvent, QuantitySelectorUpdateEvent, ThemeEvents, VariantUpdateEvent, ZoomMediaSelectedEvent

### Community 20 - "HeaderDrawer"
Cohesion: 0.10
Nodes (9): CollectionLinks, cycleFocus(), getFocusableElements(), removeTrapFocus(), trapFocus(), trapFocusHandlers, HeaderDrawer, reset() (+1 more)

### Community 23 - "HeaderMenu"
Cohesion: 0.17
Nodes (3): findMenuItem(), findSubmenu(), HeaderMenu

### Community 24 - "VariantPicker"
Cohesion: 0.09
Nodes (17): LocalPickup, collectHydrationTargets(), copyAttributes(), getNodeKey(), morph(), MORPH_OPTIONS, morphHydrationByKey(), recreateAppBlockScripts() (+9 more)

### Community 26 - "CartItemsComponent"
Cohesion: 0.08
Nodes (13): CartDiscount, CartItemsComponent, ProductRecommendations, hydrate(), hydrateSection(), buildSectionRenderingURL(), buildSectionSelector(), containsShadowRoot() (+5 more)

### Community 27 - "morph"
Cohesion: 0.21
Nodes (7): SlideshowSelectEvent, center(), clamp(), closest(), getVisibleElements(), preventDefault(), Scheduler

### Community 30 - "product-card.js"
Cohesion: 0.14
Nodes (8): DeclarativeShadowElement, VariantSelectedEvent, FlyToCart, OverflowMinimumEvent, getViewParameterValue(), isDesktopBreakpoint(), ResizeNotifier, yieldToMainThread()

### Community 33 - "compilerOptions"
Cohesion: 0.15
Nodes (12): compilerOptions, baseUrl, checkJs, noImplicitAny, noUncheckedIndexedAccess, paths, strictNullChecks, target (+4 more)

### Community 38 - "jkl-search-drawer.js"
Cohesion: 0.27
Nodes (8): init(), closeDrawer(), fetchResults(), openDrawer(), renderLoading(), renderNoResults(), renderProducts(), syncHeaderSearchToDrawer()

### Community 39 - "theme-editor.js"
Cohesion: 0.18
Nodes (4): carouselState, isIOS, layeredSlideshowState, slideshowState

### Community 49 - "debounce"
Cohesion: 0.20
Nodes (4): MegaMenuHoverEvent, ANIMATION_OPTIONS, debounce(), viewTransition

## Knowledge Gaps
- **28 isolated node(s):** `BlogPostsList`, `CartNote`, `trapFocusHandlers`, `Theme`, `Window` (+23 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **39 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Component` connect `component.js` to `facets.js`, `startViewTransition`, `utilities.js`, `Scroller`, `qr-code-generator.js`, `debounce`, `onAnimationEnd`, `events.js`, `HeaderDrawer`, `VariantPicker`, `CartItemsComponent`, `morph`, `product-card.js`?**
  _High betweenness centrality (0.192) - this node is a cross-community bridge._
- **Why does `OverflowList` connect `OverflowList` to `product-card.js`?**
  _High betweenness centrality (0.072) - this node is a cross-community bridge._
- **Why does `Slideshow` connect `Slideshow` to `morph`?**
  _High betweenness centrality (0.067) - this node is a cross-community bridge._
- **What connects `BlogPostsList`, `CartNote`, `trapFocusHandlers` to the rest of the system?**
  _28 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Slideshow` be split into smaller, more focused modules?**
  _Cohesion score 0.0707070707070707 - nodes in this community are weakly interconnected._
- **Should `facets.js` be split into smaller, more focused modules?**
  _Cohesion score 0.05706214689265537 - nodes in this community are weakly interconnected._
- **Should `startViewTransition` be split into smaller, more focused modules?**
  _Cohesion score 0.05928614640048397 - nodes in this community are weakly interconnected._